<?= $this->extend('layout') ?>

<?= $this->section('content') ?>

<div class="card">
    <div class="card-header">
        <div>
            <i class="fas fa-database"></i> User Directory
            <span class="badge-count ms-2"><?= $pager->getTotal() ?> Total Users</span>
        </div>
    </div>
    
    <div class="card-body">
        <!-- Search Bar -->
        <div class="search-container">
            <div class="search-wrapper">
                <form method="get" class="search-input-group">
                    <div class="search-icon" style="flex: 1; position: relative;">
                        <i class="fas fa-search" style="position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #94a3b8;"></i>
                        <input type="text" 
                               name="search" 
                               class="search-input" 
                               style="width: 100%; padding-left: 40px;"
                               placeholder="Search by name or email..." 
                               value="<?= esc($search ?? '') ?>">
                    </div>
                    <button type="submit" class="btn-search">
                        <i class="fas fa-search"></i> Search
                    </button>
                    <?php if($search): ?>
                        <a href="/users" class="btn-clear">
                            <i class="fas fa-times"></i> Clear
                        </a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        
        <!-- Users Table -->
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="5%">#ID</th>
                        <th width="12%">PHOTO</th>
                        <th width="28%">FULL NAME</th>
                        <th width="30%">EMAIL ADDRESS</th>
                        <th width="15%">JOINED DATE</th>
                        <th width="10%">ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($users)): ?>
                        <tr>
                            <td colspan="6" class="text-center py-5">
                                <div style="color: #94a3b8;">
                                    <i class="fas fa-user-slash" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
                                    No users found matching "<strong><?= esc($search) ?></strong>"
                                </div>
                                <a href="/users" class="btn btn-primary btn-sm mt-3">
                                    <i class="fas fa-arrow-left"></i> View all users
                                </a>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($users as $user): ?>
                            <tr>
                                <td class="fw-semibold" style="color: #0a2540; font-weight: 700;"><?= $user['id'] ?></td>
                                <td>
                                    <?php if(!empty($user['avatar']) && file_exists(FCPATH . $user['avatar'])): ?>
                                        <img src="<?= base_url($user['avatar']) ?>" 
                                             style="width: 96px; height: 96px; object-fit: cover; border-radius: 12px;">
                                    <?php else: ?>
                                        <div style="width: 96px; height: 96px; background-color: #0a2540; color: white; border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; font-weight: 800; font-size: 2rem;">
                                            <?php 
                                            $nameParts = explode(' ', $user['username']);
                                            $initial = strtoupper(substr($nameParts[0], 0, 1));
                                            echo $initial;
                                            ?>
                                        </div>
                                    <?php endif; ?>
                                 </div>
                                 </div>
                                 </div>
                                 </td>
                                <td>
                                    <div style="font-weight: 700; font-size: 1rem; color: #0a2540;"><?= esc($user['username']) ?></div>
                                    <div class="small text-muted mt-1">
                                        <i class="fas fa-id-card fa-xs"></i> ID: <?= $user['id'] ?>
                                    </div>
                                 </div>
                                 </div>
                                 </div>
                                 </td>
                                <td>
                                    <a href="mailto:<?= esc($user['email']) ?>" style="color: #0a2540; text-decoration: none; font-weight: 500;">
                                        <i class="fas fa-envelope" style="color: #64748b; width: 20px;"></i>
                                        <?= esc($user['email']) ?>
                                    </a>
                                 </div>
                                 </div>
                                 </div>
                                 </div>
                                 </td>
                                <td>
                                    <i class="far fa-calendar-alt" style="color: #64748b;"></i>
                                    <?= date('M d, Y', strtotime($user['created_at'])) ?>
                                 </div>
                                 </div>
                                 </div>
                                 </td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <a href="/user/edit/<?= $user['id'] ?>" 
                                           class="btn btn-outline-warning btn-sm"
                                           title="Edit User">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <a href="/user/delete/<?= $user['id'] ?>" 
                                           class="btn btn-outline-danger btn-sm"
                                           onclick="return confirm('⚠️ Delete <?= esc($user['username']) ?>?\n\nThis action cannot be undone.')"
                                           title="Delete User">
                                            <i class="fas fa-trash-alt"></i> Delete
                                        </a>
                                    </div>
                                 </div>
                                 </div>
                                 </div>
                                 </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- SIMPLE PAGINATION - Using CI4 Built-in Links -->
        <?php if(!empty($users)): ?>
            <div class="pagination-wrapper">
                <div class="pagination-container">
                    <?= $pager->links() ?>
                </div>
                <div class="pagination-info">
                    <i class="fas fa-chart-line"></i>
                    Showing <strong><?= count($users) ?></strong> of <strong><?= $pager->getTotal() ?></strong> users
                    <?php if($search): ?>
                        <span class="badge-count ms-2">
                            <i class="fas fa-filter"></i> Filtered: "<?= esc($search) ?>"
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?= $this->endSection() ?>