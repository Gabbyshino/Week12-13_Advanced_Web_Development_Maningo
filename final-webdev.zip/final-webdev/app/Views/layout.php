<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management System | Enterprise Dashboard</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background-color: #f4f6f9;
            color: #1a2a3e;
            line-height: 1.5;
        }
        
        /* ========== NAVIGATION BAR ========== */
        .navbar {
            background-color: #0a2540;
            padding: 0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            border-bottom: 1px solid #1e3a5f;
        }
        
        .navbar .container {
            padding: 0.75rem 1.5rem;
        }
        
        /* ORANGE 1: Bigger and Bolder Title */
        .navbar-brand {
            font-size: 1.75rem !important;
            font-weight: 800 !important;
            letter-spacing: -0.5px;
            color: white !important;
            padding: 0;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .navbar-brand i {
            font-size: 1.8rem;
            color: #60a5fa;
        }
        
        /* RED 3: Navigation Links with Underline Effect */
        .nav-links {
            display: flex;
            gap: 0.5rem;
            align-items: center;
        }
        
        .nav-link-custom {
            font-weight: 700 !important;
            font-size: 0.95rem;
            padding: 0.5rem 1.25rem !important;
            color: #e2e8f0 !important;
            text-decoration: none;
            transition: all 0.2s ease;
            border-radius: 6px;
            position: relative;
        }
        
        /* Active link with glow line under it */
        .nav-link-custom.active {
            color: white !important;
        }
        
        .nav-link-custom.active::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 50%;
            transform: translateX(-50%);
            width: 80%;
            height: 3px;
            background-color: #60a5fa;
            border-radius: 3px;
            box-shadow: 0 0 8px rgba(96, 165, 250, 0.6);
        }
        
        .nav-link-custom:hover {
            color: white !important;
            background-color: rgba(255, 255, 255, 0.08);
        }
        
        .nav-link-custom i {
            margin-right: 8px;
            font-size: 0.9rem;
        }
        
        /* ========== MAIN CONTAINER ========== */
        .main-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem 1.5rem;
        }
        
        /* ========== CARDS ========== */
        .card {
            border: none;
            border-radius: 12px;
            background: white;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.03);
            transition: box-shadow 0.2s ease;
        }
        
        .card:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }
        
        /* ORANGE 2: Bigger and Bolder User Directory Title */
        .card-header {
            background: white;
            border-bottom: 1px solid #e9ecef;
            padding: 1.5rem 1.5rem;
            font-weight: 800 !important;
            font-size: 1.3rem !important;
            color: #0a2540;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .card-header i {
            color: #0a2540;
            margin-right: 10px;
            font-size: 1.3rem;
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        /* ========== BUTTONS ========== */
        .btn {
            font-weight: 600;
            font-size: 0.875rem;
            padding: 0.5rem 1.25rem;
            border-radius: 8px;
            transition: all 0.2s ease;
            letter-spacing: -0.2px;
        }
        
        .btn-primary {
            background-color: #0a2540;
            border-color: #0a2540;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #1e3a5f;
            border-color: #1e3a5f;
            transform: translateY(-1px);
        }
        
        .btn-secondary {
            background-color: #64748b;
            border-color: #64748b;
            color: white;
        }
        
        .btn-secondary:hover {
            background-color: #475569;
            border-color: #475569;
        }
        
        .btn-outline-warning {
            color: #d97706;
            border-color: #fde68a;
            background-color: #fffbeb;
        }
        
        .btn-outline-warning:hover {
            background-color: #d97706;
            border-color: #d97706;
            color: white;
        }
        
        .btn-outline-danger {
            color: #dc2626;
            border-color: #fee2e2;
            background-color: #fef2f2;
        }
        
        .btn-outline-danger:hover {
            background-color: #dc2626;
            border-color: #dc2626;
            color: white;
        }
        
        .btn-sm {
            padding: 0.375rem 0.875rem;
            font-size: 0.8125rem;
        }
        
        /* ========== TABLE ========== */
        .table {
            margin-bottom: 0;
            font-size: 0.875rem;
        }
        
        .table thead th {
            background-color: #f8fafc;
            border-bottom: 2px solid #e2e8f0;
            color: #1e293b;
            font-weight: 700;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 1rem 0.75rem;
        }
        
        .table tbody td {
            padding: 1rem 0.75rem;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
        }
        
        .table tbody tr:hover {
            background-color: #fafcff;
            transition: background-color 0.2s ease;
        }
        
        /* RED 1: Bigger Photo Display (1 inch = ~96px) */
        .avatar-img {
            width: 96px !important;
            height: 96px !important;
            object-fit: cover;
            border-radius: 12px;
            border: 2px solid #e2e8f0;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        
        .avatar-initials {
            width: 96px !important;
            height: 96px !important;
            background-color: #0a2540;
            color: white;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 2rem;
            border: 2px solid #e2e8f0;
        }
        
        /* Make table rows taller for bigger photos */
        .table tbody td {
            padding: 1.2rem 0.75rem;
        }
        
        /* ========== SEARCH BAR - ORANGE 3 ========== */
        .search-container {
            display: flex;
            justify-content: center;
            margin-bottom: 1.5rem;
        }
        
        .search-wrapper {
            max-width: 600px;
            width: 100%;
        }
        
        .search-input-group {
            display: flex;
            gap: 12px;
            align-items: center;
            width: 100%;
        }
        
        .search-input {
            flex: 1;
            padding: 0.75rem 1rem 0.75rem 2.5rem;
            border: 1.5px solid #e2e8f0;
            border-radius: 12px;
            font-size: 0.9rem;
            transition: all 0.2s ease;
            font-family: 'Inter', sans-serif;
            background-color: white;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #0a2540;
            box-shadow: 0 0 0 3px rgba(10, 37, 64, 0.1);
        }
        
        .search-input::placeholder {
            color: #94a3b8;
        }
        
        .search-icon {
            position: relative;
        }
        
        .search-icon i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        /* Search Button - Perfectly centered text */
        .btn-search {
            background-color: #0a2540;
            border: none;
            color: white;
            padding: 0.75rem 1.75rem;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s ease;
            white-space: nowrap;
        }
        
        .btn-search:hover {
            background-color: #1e3a5f;
            transform: translateY(-1px);
        }
        
        .btn-clear {
            background-color: #64748b;
            border: none;
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s ease;
        }
        
        .btn-clear:hover {
            background-color: #475569;
        }
        
        /* ========== PAGINATION - WITH NUMBERED BUTTONS & ARROWS ========== */
.pagination-wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin-top: 2rem;
    padding-top: 1.5rem;
    border-top: 1px solid #e9ecef;
}

.pagination-container {
    display: flex;
    justify-content: center;
    margin-bottom: 1rem;
}

.pagination {
    margin: 0;
    gap: 8px;
    display: flex;
    list-style: none;
    padding: 0;
}

/* All pagination buttons - ROUNDED BUTTONS */
.pagination .page-item {
    display: inline-block;
}

.pagination .page-link {
    border-radius: 10px;
    border: 1.5px solid #0a2540;
    padding: 0.6rem 1rem;
    font-size: 0.875rem;
    font-weight: 700;
    background-color: white;
    color: #0a2540;
    transition: all 0.2s ease;
    min-width: 42px;
    text-align: center;
    cursor: pointer;
    display: inline-block;
    text-decoration: none;
}

/* Hover effect for all buttons */
.pagination .page-link:hover {
    background-color: #0a2540;
    border-color: #0a2540;
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(10, 37, 64, 0.15);
}

/* ACTIVE page button (current page) - Navy Blue with White Text */
.pagination .page-item.active .page-link {
    background-color: #0a2540;
    border-color: #0a2540;
    color: white;
    box-shadow: 0 2px 8px rgba(10, 37, 64, 0.2);
}

/* DISABLED buttons (Previous/Next when not available) */
.pagination .page-item.disabled .page-link {
    background-color: #f1f5f9;
    border-color: #cbd5e1;
    color: #94a3b8;
    cursor: not-allowed;
    transform: none;
    opacity: 0.6;
}

/* All number buttons stay BLUE text with WHITE background */
.pagination .page-item:not(.active):not(.disabled) .page-link {
    background-color: white;
    border-color: #0a2540;
    color: #0a2540;
}

/* Hover for number buttons becomes navy with white text */
.pagination .page-item:not(.active):not(.disabled) .page-link:hover {
    background-color: #0a2540;
    color: white;
}

/* Pagination info text below buttons */
.pagination-info {
    text-align: center;
    font-size: 0.875rem;
    color: #64748b;
    margin-top: 0.75rem;
}

.pagination-info strong {
    color: #0a2540;
    font-weight: 700;
}


        
        /* ========== FORM STYLES ========== */
        .form-label {
            font-weight: 600;
            font-size: 0.875rem;
            color: #1e293b;
            margin-bottom: 0.5rem;
        }
        
        .form-control {
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 0.625rem 1rem;
            font-size: 0.875rem;
            font-family: 'Inter', sans-serif;
            transition: all 0.2s ease;
        }
        
        .form-control:focus {
            border-color: #0a2540;
            box-shadow: 0 0 0 3px rgba(10, 37, 64, 0.1);
            outline: none;
        }
        
        .form-text {
            font-size: 0.75rem;
            color: #64748b;
            margin-top: 0.375rem;
        }
        
        /* ========== ALERTS ========== */
        .alert {
            border-radius: 10px;
            border: none;
            padding: 1rem 1.25rem;
            font-size: 0.875rem;
            margin-bottom: 1.5rem;
        }
        
        .alert-success {
            background-color: #ecfdf5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }
        
        .alert-danger {
            background-color: #fef2f2;
            color: #991b1b;
            border-left: 4px solid #ef4444;
        }
        
        .alert-warning {
            background-color: #fffbeb;
            color: #92400e;
            border-left: 4px solid #f59e0b;
        }
        
        /* ========== BADGES ========== */
        .badge-count {
            background-color: #e2e8f0;
            color: #0a2540;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        /* ========== FOOTER ========== */
        .footer {
            text-align: center;
            padding: 1.5rem;
            color: #64748b;
            font-size: 0.75rem;
            border-top: 1px solid #e9ecef;
            margin-top: 2rem;
            background-color: white;
        }
        
        /* ========== RESPONSIVE ========== */
        @media (max-width: 768px) {
            .main-container {
                padding: 1rem;
            }
            
            .card-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .search-wrapper {
                max-width: 100%;
            }
            
            .pagination-container {
                overflow-x: auto;
            }
            
            .table {
                font-size: 0.75rem;
            }
            
            .avatar-img, .avatar-initials {
                width: 60px !important;
                height: 60px !important;
            }
            
            .btn-sm {
                padding: 0.25rem 0.5rem;
                font-size: 0.7rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="/users">
                <i class="fas fa-users"></i>
                <span>User Management System</span>
            </a>
            <div class="nav-links">
                <a class="nav-link-custom <?= (current_url() == base_url('/users') || current_url() == base_url('/')) ? 'active' : '' ?>" href="/users">
                    <i class="fas fa-table-list"></i> Users List
                </a>
                <a class="nav-link-custom <?= (strpos(current_url(), '/user/create') !== false || strpos(current_url(), '/user/edit') !== false) ? 'active' : '' ?>" href="/user/create">
                    <i class="fas fa-user-plus"></i> Add User
                </a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="main-container">
        <!-- Flash Messages -->
        <?php if(session()->getFlashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i>
                <strong>Success!</strong> <?= session()->getFlashdata('success') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if(session()->getFlashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>Error!</strong> <?= session()->getFlashdata('error') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if(session()->getFlashdata('errors')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-times-circle me-2"></i>
                <strong>Validation Errors:</strong>
                <ul class="mb-0 mt-2">
                    <?php foreach(session()->getFlashdata('errors') as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Page Content -->
        <?= $this->renderSection('content') ?>
    </div>
    
    <div class="footer">
        <i class="fas fa-code me-1"></i> User Management System | Powered by CodeIgniter 4
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>