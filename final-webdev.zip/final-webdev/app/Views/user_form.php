<?= $this->extend('layout') ?>

<?= $this->section('content') ?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <i class="fas <?= isset($user) ? 'fa-user-edit' : 'fa-user-plus' ?>"></i>
                <?= isset($user) ? 'Edit User Profile' : 'Create New User' ?>
            </div>
            
            <div class="card-body">
                <!-- IMPORTANT: enctype="multipart/form-data" is CRITICAL for file upload -->
                <form method="post" 
                      action="<?= isset($user) ? '/user/update/' . $user['id'] : '/user/store' ?>" 
                      enctype="multipart/form-data">
                    
                    <!-- Username Field -->
                    <div class="mb-4">
                        <label for="username" class="form-label">
                            <i class="fas fa-user-circle"></i> Full Name <span class="text-danger">*</span>
                        </label>
                        <input type="text" 
                               name="username" 
                               id="username" 
                               class="form-control form-control-lg" 
                               value="<?= old('username') ?? ($user['username'] ?? '') ?>" 
                               placeholder="e.g., Gabriel Maningo"
                               required>
                        <div class="form-text">
                            <i class="fas fa-info-circle"></i> Enter the user's complete name
                        </div>
                    </div>

                    <!-- Email Field -->
                    <div class="mb-4">
                        <label for="email" class="form-label">
                            <i class="fas fa-envelope"></i> Email Address <span class="text-danger">*</span>
                        </label>
                        <input type="email" 
                               name="email" 
                               id="email" 
                               class="form-control form-control-lg" 
                               value="<?= old('email') ?? ($user['email'] ?? '') ?>" 
                               placeholder="e.g., name@example.com"
                               required>
                        <div class="form-text">
                            <i class="fas fa-info-circle"></i> Must be a valid and unique email address
                        </div>
                    </div>

                    <!-- Avatar Upload Field - PHOTO UPLOAD HERE -->
                    <div class="mb-4">
                        <label for="avatar" class="form-label">
                            <i class="fas fa-camera"></i> Profile Picture
                        </label>
                        
                        <!-- Show current avatar if editing -->
                        <?php if(isset($user) && $user['avatar'] && file_exists(FCPATH . $user['avatar'])): ?>
                            <div class="mb-3 p-3 bg-light rounded" style="background-color: #f8fafc !important;">
                                <div class="d-flex align-items-center gap-3">
                                    <img src="<?= base_url($user['avatar']) ?>" 
                                         style="width: 80px; height: 80px; object-fit: cover; border-radius: 12px; border: 2px solid #e2e8f0;"
                                         alt="Current Avatar">
                                    <div>
                                        <div class="fw-semibold" style="color: #0a2540;">Current Avatar</div>
                                        <div class="small text-muted">You can upload a new image below</div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <input type="file" 
                               name="avatar" 
                               id="avatar" 
                               class="form-control" 
                               accept="image/jpeg,image/png,image/gif,image/webp">
                        
                        <div class="form-text mt-2">
                            <i class="fas fa-image"></i> 
                            <strong>Supported formats:</strong> JPEG, PNG, GIF, WEBP &nbsp;|&nbsp;
                            <strong>Max size:</strong> 2MB &nbsp;|&nbsp;
                            <strong>Recommended:</strong> Square image (500x500px)
                        </div>
                        
                        <!-- Preview uploaded image before submit -->
                        <div id="imagePreview" class="mt-3" style="display: none;">
                            <label class="form-label">Preview:</label>
                            <img id="previewImg" style="width: 100px; height: 100px; object-fit: cover; border-radius: 12px; border: 2px solid #e2e8f0;">
                        </div>
                    </div>

                    <!-- Form Actions -->
                    <div class="d-flex gap-3 mt-4 pt-3 border-top">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas <?= isset($user) ? 'fa-save' : 'fa-check-circle' ?>"></i>
                            <?= isset($user) ? ' Update User' : ' Create User' ?>
                        </button>
                        <a href="/users" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Image preview before upload
document.getElementById('avatar').addEventListener('change', function(e) {
    const preview = document.getElementById('imagePreview');
    const previewImg = document.getElementById('previewImg');
    
    if (e.target.files && e.target.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            preview.style.display = 'block';
        }
        reader.readAsDataURL(e.target.files[0]);
    } else {
        preview.style.display = 'none';
    }
});
</script>

<?= $this->endSection() ?>