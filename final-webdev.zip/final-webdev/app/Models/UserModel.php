<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = ['username', 'email', 'avatar'];
    
    // Disable automatic timestamps since your table doesn't have updated_at
    protected $useTimestamps = false;
    
    // Only use created_at if you want
    // protected $useTimestamps = true;
    // protected $createdField = 'created_at';
    // protected $updatedField = 'updated_at';
}