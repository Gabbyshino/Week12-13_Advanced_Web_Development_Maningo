<?php

namespace App\Controllers;

use App\Models\UserModel;

class UserController extends BaseController
{
    // MAIN PAGE - Show all users (5 per page)
    public function index()
    {
        $model = new UserModel();
        
        // Check if user is searching
        $search = $this->request->getGet('search');
        
        if ($search) {
            $users = $model->like('username', $search)
                          ->orLike('email', $search)
                          ->paginate(5);
        } else {
            $users = $model->paginate(5);
        }
        
        $data = [
            'users' => $users,
            'pager' => $model->pager,
            'search' => $search
        ];
        
        return view('user_list', $data);
    }
    
    // SHOW FORM - Create new user
    public function create()
    {
        return view('user_form');
    }
    
    // SAVE USER - Store in database with photo
    public function store()
    {
        $model = new UserModel();
        
        // Validation rules
        $rules = [
            'username' => 'required|min_length[3]|max_length[100]',
            'email' => 'required|valid_email|is_unique[users.email]'
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        // Prepare user data
        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email')
        ];
        
        // Handle profile picture upload
        $avatar = $this->request->getFile('avatar');
        
        if ($avatar && $avatar->isValid() && !$avatar->hasMoved()) {
            // Allowed image types
            $validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $maxSize = 2 * 1024 * 1024; // 2MB
            
            // Check file type
            if (!in_array($avatar->getMimeType(), $validTypes)) {
                return redirect()->back()->withInput()->with('error', 'Only JPEG, PNG, GIF, or WEBP images allowed.');
            }
            
            // Check file size
            if ($avatar->getSize() > $maxSize) {
                return redirect()->back()->withInput()->with('error', 'Image must be less than 2MB.');
            }
            
            // Create uploads folder if it doesn't exist
            $uploadPath = WRITEPATH . '../public/uploads';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }
            
            // Generate unique filename and save
            $newName = $avatar->getRandomName();
            $avatar->move($uploadPath, $newName);
            
            // Store path in database
            $data['avatar'] = 'uploads/' . $newName;
        }
        
        // Save to database
        $model->save($data);
        
        return redirect()->to('/users')->with('success', 'User created successfully with profile picture!');
    }
    
    // EDIT FORM - Show user data for editing
    public function edit($id)
    {
        $model = new UserModel();
        $user = $model->find($id);
        
        if (!$user) {
            return redirect()->to('/users')->with('error', 'User not found.');
        }
        
        return view('user_form', ['user' => $user]);
    }
    
    // UPDATE USER - Save changes with new photo
    public function update($id)
    {
        $model = new UserModel();
        $user = $model->find($id);
        
        if (!$user) {
            return redirect()->to('/users')->with('error', 'User not found.');
        }
        
        // Validation rules (email unique except current user)
        $rules = [
            'username' => 'required|min_length[3]|max_length[100]',
            'email' => 'required|valid_email|is_unique[users.email,id,' . $id . ']'
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email')
        ];
        
        // Handle new profile picture
        $avatar = $this->request->getFile('avatar');
        
        if ($avatar && $avatar->isValid() && !$avatar->hasMoved()) {
            $validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $maxSize = 2 * 1024 * 1024;
            
            if (!in_array($avatar->getMimeType(), $validTypes)) {
                return redirect()->back()->withInput()->with('error', 'Only JPEG, PNG, GIF, or WEBP images allowed.');
            }
            
            if ($avatar->getSize() > $maxSize) {
                return redirect()->back()->withInput()->with('error', 'Image must be less than 2MB.');
            }
            
            // Delete old avatar if exists
            if ($user['avatar'] && file_exists(WRITEPATH . '../public/' . $user['avatar'])) {
                unlink(WRITEPATH . '../public/' . $user['avatar']);
            }
            
            // Create uploads folder if it doesn't exist
            $uploadPath = WRITEPATH . '../public/uploads';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }
            
            // Save new avatar
            $newName = $avatar->getRandomName();
            $avatar->move($uploadPath, $newName);
            $data['avatar'] = 'uploads/' . $newName;
        }
        
        // Update database
        $model->update($id, $data);
        
        return redirect()->to('/users')->with('success', 'User updated successfully with new profile picture!');
    }
    
    // DELETE USER - Remove from database and delete photo
    public function delete($id)
    {
        $model = new UserModel();
        $user = $model->find($id);
        
        // Delete avatar file if exists
        if ($user && $user['avatar']) {
            $avatarPath = WRITEPATH . '../public/' . $user['avatar'];
            if (file_exists($avatarPath)) {
                unlink($avatarPath);
            }
        }
        
        // Delete from database
        $model->delete($id);
        
        return redirect()->to('/users')->with('success', 'User deleted successfully!');
    }
}