<?php

namespace Config;

$routes = Services::routes();

if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('UserController');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

// ====================
// USER ROUTES
// ====================

$routes->get('/', 'UserController::index');           // Homepage
$routes->get('/users', 'UserController::index');      // User list
$routes->get('/user/create', 'UserController::create'); // Add form
$routes->post('/user/store', 'UserController::store');  // Save user
$routes->get('/user/edit/(:num)', 'UserController::edit/$1');   // Edit form
$routes->post('/user/update/(:num)', 'UserController::update/$1'); // Update user
$routes->get('/user/delete/(:num)', 'UserController::delete/$1'); // Delete user